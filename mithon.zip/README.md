# Mixly_Lite

This is a [preview edition](https://www.mithon.org/ "Mixly Lite"). 

### v 0.2
- [ ] Support micro:bit
- [ ] Support python 3 (use skulpt)
- [ ] Support mixIO
---
### v 0.1
- [x] A demo, only support Mithon
